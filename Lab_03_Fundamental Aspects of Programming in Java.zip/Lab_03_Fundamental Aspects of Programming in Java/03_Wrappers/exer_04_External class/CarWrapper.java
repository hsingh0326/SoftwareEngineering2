// A Wrapper over class that is used for swapping
class CarWrapper
{
Car c;
// Constructor
CarWrapper(Car c) {this.c = c;}
}