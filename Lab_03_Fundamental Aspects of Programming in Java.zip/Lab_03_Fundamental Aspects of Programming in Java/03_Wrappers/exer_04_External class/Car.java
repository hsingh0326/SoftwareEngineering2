// A Java program to demonstrate that we can use wrapper
// classes to swap to objects
// A car with model and no.
class Car
{
int model, no;
// Constructor
Car(int model, int no)
{
this.model = model;
this.no = no;
}
// Utility method to print object details
void print()
{
System.out.println("no = " + no +
", model = " + model);
}
}
